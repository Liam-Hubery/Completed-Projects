from tkinter import*
import tkinter.messagebox as mb
def changeDict(original, later, key):
    global theVal
    global theKey
    if key not in original:
        mb.showerror("Error", "Code Not Found")
    else:
        theVal=original[key]
        theKeypart=list(original).index(key)
        theKey=list(original)[theKeypart]
        later[theKey]=theVal
        original.pop(theKey)
def fileRewrite(dic1, dic2, dic3):
    with open("bookfile.txt", "w") as f:
        f.truncate(0)
        f.write(str(dic1)+"\n")
        f.write(str(dic2)+"\n")
        f.write(str(dic3)+"\n")
        
