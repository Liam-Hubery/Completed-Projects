from tkinter import*
#from tkinter.ttk import*
import time
import sys
import random
import tkinter.messagebox as mb
import functools
from dicttools import changeDict, fileRewrite
import json
import ast

#File Instructions Here


global e

e=open("bookfile.txt", "r")
hi=(e.readline(-1)).replace("\n", "")
he=(e.readline(-1)).replace("\n", "")
ha=(e.readline(-1)).replace("\n", "")

root=Tk()
books=ast.literal_eval(hi)
inbooks=ast.literal_eval(he)
outbooks=ast.literal_eval(ha)
class Appsimple:
    def info(title, text):
        mb.showinfo(title, text)
    def yesno(title, text):
        mb.askyesno(title, text)
    def warning(title, text):
        mb.showwarning(title, text)
    def error(title, text):
        mb.showerror(title, text)

theapp=Appsimple


headFrame=Frame()
headFrame.grid(column=0, row=0, padx=20, pady=15)
sortFrame=Frame()
sortFrame.grid(column=0, row=1, padx=10, pady=5)

thequestion=Label(headFrame, text="What would you like to do?")
thequestion.grid(column=0, row=0, padx=5, pady=5)

def submit(bookbox, authourbox):
    global books
    global book

    book=str(bookbox.get()+" by "+authourbox.get())
    authour=random.randint(0, 9999)
    global authstr
    authstr=""
    while str(authour) in authstr:
        authour=random.randint(0, 9999)
    
    if authour<10:
        authstr="000"+str(authour)
    elif authour<100:
        authstr="00"+str(authour)
    elif authour<1000:
        authstr="0"+str(authour)
    else:
        authstr=str(authour)
    books[authstr]=book
    global inbooks
    inbooks[authstr]=book
    bookbox.delete(0, 'end')
    authourbox.delete(0, 'end')
    fileRewrite(books, inbooks, outbooks)
    
    
def submitone(bookbox):
    boxes=Appsimple
    global books
    book=answerbox.get()
    question=mb.askyesno("Deleting", "Are you sure?")
    if question==True:
        books.pop(str(book))
        inbooks.pop(str(book))
        outbooks.pop(str(book))
        global book_name
        fileRewrite(books, inbooks, outbooks)

def submitissue():
    boxes=Appsimple
    global books
    global book
    book=answerbox.get()
    question=mb.askyesno("Issuing", "Are you sure?")
    if question==True:
        changeDict(inbooks, outbooks, book)
        global book_name
        fileRewrite(books, inbooks, outbooks)

def submitreturn():
    boxes=Appsimple
    global books
    book=answerbox.get()
    question=mb.askyesno("Returning", "Are you sure?")
    if question==True:
        changeDict(outbooks, inbooks, book)
        global book_name
        fileRewrite(books, inbooks, outbooks)

def addingbook():
    anewwin=Toplevel(root)
    anewwin.title("Adding a Book")
    thetext=Label(anewwin, text="Title: ")
    thetext.grid(column=0, row=0, pady=5, padx=5)
    titlebox=Entry(anewwin, width=40)
    titlebox.grid(column=1, row=0, pady=5, padx=5)
    othertext=Label(anewwin, text="Authour: ")
    othertext.grid(column=0, row=1, pady=5, padx=5)
    authourbox=Entry(anewwin, width=40)
    authourbox.grid(column=1, row=1, pady=5, padx=5)
    
    submitadd=functools.partial(submit, titlebox, authourbox)
    submitbutt=Button(anewwin, text="Submit", command=submitadd)
    submitbutt.grid(column=1, row=2, padx=5, pady=5)

def deletebook():
    boxes=Appsimple
    if len(books)==0:
        boxes.error("Error", "No Books")
    else:
        global bookstring
        bookstring=""
        global book_keys
        global book_values
        global book_name
        book_name=[]
        book_keys, book_values=zip(*books.items())
        for i in range(0, len(book_keys)):
            book_name.append(book_keys[i])
        global anewwin
        anewwin=Toplevel(root)
        anewwin.title("Deleting a Book")
        thetext=Label(anewwin, text="Book Code: ")
        thetext.grid(column=0, row=0, pady=5, padx=5)
        global answerbox
        answerbox=Entry(anewwin, width=80)
        answerbox.grid(column=1, row=0, pady=5, padx=5)
    
    
        submitdel=functools.partial(submitone, answerbox)
        submitbutt=Button(anewwin, text="Submit", command=submitdel)
        submitbutt.grid(column=1, row=2, padx=5, pady=5)
    
def issuebook():
    boxes=Appsimple
    if len(books)==0:
        boxes.error("Error", "No Books")
    elif len(inbooks)==0:
        boxes.error("Error", "No Books Available")
    else:
        global bookstring
        bookstring=""
        global book_keys
        global book_values
        global book_name
        book_name=[]
        book_keys, book_values=zip(*books.items())
        for i in range(0, len(book_keys)):
            book_name.append(book_keys[i])
        global anewwin
        anewwin=Toplevel(root)
        anewwin.title("Issuing a Book")
        thetext=Label(anewwin, text="Book Code: ")
        thetext.grid(column=0, row=0, pady=5, padx=5)
        global answerbox
        answerbox=Entry(anewwin, width=80)
        answerbox.grid(column=1, row=0, pady=5, padx=5)
    
    
        submitdel=functools.partial(submitone, answerbox)
        submitbutt=Button(anewwin, text="Submit", command=submitissue)
        submitbutt.grid(column=1, row=2, padx=5, pady=5)

def returnbook():
    boxes=Appsimple
    if len(books)==0:
        boxes.error("Error", "No Books")
    elif len(outbooks)==0:
        boxes.error("Error", "No Books Issued")
    else:
        global bookstring
        bookstring=""
        global book_keys
        global book_values
        global book_name
        book_name=[]
        book_keys, book_values=zip(*books.items())
        for i in range(0, len(book_keys)):
            book_name.append(book_keys[i])
        global anewwin
        anewwin=Toplevel(root)
        anewwin.title("Returning a Book")
        thetext=Label(anewwin, text="Book Code: ")
        thetext.grid(column=0, row=0, pady=5, padx=5)
        global answerbox
        answerbox=Entry(anewwin, width=80)
        answerbox.grid(column=1, row=0, pady=5, padx=5)
    
        submitdel=functools.partial(submitone, answerbox)
        submitbutt=Button(anewwin, text="Submit", command=submitreturn)
        submitbutt.grid(column=1, row=2, padx=5, pady=5)

def listbooks():
    
    boxes=Appsimple
    if len(books)==0:
        boxes.error("Error", "No Books")
    else:
        
        global bookstring
        bookstring=""
        global book_keys
        global book_values
        book_values, book_keys=zip(*books.items())
        for i in range(0, len(book_values)):
            bookstring+=book_keys[i]
            bookstring+=" | Code: "
            bookstring+=book_values[i]
            if book_values[i] in inbooks:
                bookstring+=" | IN"
            elif book_values[i] in outbooks:
                bookstring+= " | OUT"
            bookstring+="\n"
        anewwin=Toplevel(root)
        anewwin.title("Book List")
        dabooks=Label(anewwin, text=bookstring)
        dabooks.grid(column=0, row=0, padx=5, pady=5)

def randomBook(): 
    boxes=Appsimple
    if len(books)==0:
        boxes.error("Error", "No Books")
    elif len(inbooks)==0:
        boxes.error("Error", "No Books Available")
    else:
        global bookstring
        bookstring=""
        global book_keys
        global book_values
        book_values, book_keys=zip(*inbooks.items())
        randnum=random.randint(0, len(book_keys)-1)
        randbook=book_keys[randnum]
        randauthour=book_values[randnum]
        thebook=(randbook+" Code: "+randauthour)
        boxes.info("Book List", thebook)


addbook=Button(sortFrame, text="Add a Book", bg="DarkOliveGreen1", width=16, command=addingbook)
addbook.grid(column=0, row=0)
deletebook=Button(sortFrame, text="Delete a Book", bg="DarkOliveGreen1", width=16, command=deletebook)
deletebook.grid(column=0, row=1)
viewbook=Button(sortFrame, text="View Book List", bg="skyblue1", width=16, command=listbooks)
viewbook.grid(column=0, row=5)
issuebook=Button(sortFrame, text="Issue a Book", bg="coral1", width=16, command=issuebook)
issuebook.grid(column=0, row=3)
returnbook=Button(sortFrame, text="Return a Book", bg="coral1", width=16, command=returnbook)
returnbook.grid(column=0, row=4)
randombook=Button(sortFrame, text="Choose Random Book",bg="skyblue1",width=16, command=randomBook)
randombook.grid(column=0, row=6)
e.close()
root.mainloop()
