from pygame import mixer
from tkinter import*
import random
import time
import sys
import os
all_songs=os.listdir("music")
  
# Starting the mixer
mixer.init()
global f
f=0
themusic="music/"+all_songs[f]
root=Tk()
def nextit():
    global themusic
    global f
    f+=1
    if f>len(all_songs):
        f=0
    themusic="music/"+all_songs[f]   
    mixer.music.load(themusic)
    mixer.music.set_volume(0.7)
    mixer.music.play()
    mixer.music.pause()
    thesong.config(text=themusic)
def previt():
    global themusic
    global f
    f-=1
    themusic="music/"+all_songs[f]   
    mixer.music.load(themusic)
    mixer.music.set_volume(0.7)
    mixer.music.play()
    mixer.music.pause()
    thesong.config(text=themusic)
def shuffleit():
    global themusic
    global f
    f=random.randint(1, len(all_songs)-1)
    themusic="music/"+all_songs[f]   
    mixer.music.load(themusic)
    mixer.music.set_volume(0.7)
    mixer.music.play()
    mixer.music.pause()
    thesong.config(text=themusic)
def resume():
    mixer.music.unpause()
def pauseit():
    mixer.music.pause()
def stopit():
    mixer.music.stop()
    

thesong=Label(root, text=all_songs[f], bg="black", fg="lime")
playbutt=Button(root, text="▶", command=resume)
pausebutt=Button(root, text="II", command=pauseit)
stopbutt=Button(root, text="■", command=stopit)
nextbutt=Button(root, text="▶▶I", command=nextit)
prevbutt=Button(root, text="I◀◀", command=previt)
randomizer=Button(root, text="?", command=shuffleit)

thesong.grid(row=1, column=0)
playbutt.grid(row=1, column=1)
pausebutt.grid(row=1, column=2)
stopbutt.grid(row=1, column=3)
nextbutt.grid(row=1, column=5)
prevbutt.grid(row=1, column=4)
randomizer.grid(row=1, column=6)
root.mainloop()
